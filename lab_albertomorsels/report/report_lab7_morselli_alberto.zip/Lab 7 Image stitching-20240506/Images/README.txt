caricare le immagini dentro queste cartelle,
le ho cancellate perchè sennò lo .zip pesava troppo